package com.example.HomeDeliveryapp.adapter2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.HomeDeliveryapp.R;
import com.example.HomeDeliveryapp.shop.Shop;

import java.util.List;

class ShopsRecyclerViewAdapter extends RecyclerView.Adapter<ShopsRecyclerViewAdapter.ViewHolder> {
    private Context context;
    private List<Shop>contactInfoList;



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.shop_layout_item,parent,
                false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {

    }

    @Override
    public int getItemCount() {
        return contactInfoList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder{
        TextView edtshoptype,edtShopname,edtShopnumber,edtlocation;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            edtshoptype = itemView.findViewById(R.id.edtshoptype);
            edtShopname = itemView.findViewById(R.id.edtShopname);
            edtShopnumber= itemView.findViewById(R.id.edtShopnumber);
            edtlocation = itemView.findViewById(R.id.edtlocation);

        }
    }
}
