package com.example.HomeDeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.HomeDeliveryapp.adapter.ProductRecyclerViewAdapter;
import com.example.HomeDeliveryapp.model.Product;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    public Button button, button1, button2;
    FloatingActionButton fab;
    //firebase database
    FirebaseDatabase database;
    // firebase database reference
    DatabaseReference myRef;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        button =(Button)findViewById(R.id.createAcc);
        setContentView(R.layout.activity_login_);
        button= (Button) findViewById(R.id.createAcc);
        //set up
        //initialize

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("products");

        //write/save
        fab = findViewById(R.id.floatingActionButton9);
       fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //start activity
                startActivity(new Intent(MainActivity.this,AddProductActivity.class));
            }
        });

    }

    private void getMyData() {
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Product> productList = new ArrayList<>();

                for(DataSnapshot item:snapshot.getChildren()

                ){
                 productList.add(item.getValue(Product.class));


                }

                //adapter
                ProductRecyclerViewAdapter adapter= new ProductRecyclerViewAdapter(MainActivity.this
                        ,productList);
                recyclerView.setAdapter(adapter);


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }

        });

    }
}