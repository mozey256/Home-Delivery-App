package com.example.HomeDeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.Manifest.permission;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.squareup.okhttp.internal.Version;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class LocationActivity extends AppCompatActivity {
    private FusedLocationProviderClient fusedLocationClient;

  Context context;
  TextView txtlocation,txtAddresses;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location2);
        context = LocationActivity.this;
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        checkLocationPermission();

        Button btnGetlocation = findViewById(R.id.btnGetlocation);
        txtlocation = findViewById(R.id.txtlocation);
        txtAddresses=findViewById(R.id.txtAddresses);
        btnGetlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkLocationPermission();
            }
        });

        Button btnShowMap = findViewById(R.id.btnShowMap);
        btnShowMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // open maps activity
                // intent
                //pass lat and longt

                Intent intent = new Intent(context,MapsActivity.class);
                intent.putExtra(name: "lat", value: "");
                intent.putExtra(name: "longt", value: "");
                startActivity(intent);
            }
        });
    }
//capture permisssion
        public void checkLocationPermission(){
            if (ContextCompat.checkSelfPermission(context, permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context,permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED){
                 getMyLocation();
            }else
                {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{permission.ACCESS_COARSE_LOCATION,
                                permission.ACCESS_FINE_LOCATION}, 1111);
                    }
                }
            }
        }
        @SuppressLint("MissingPermission")
        public void getMyLocation(){
            //cordinates
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this,new OnSuccessListener<Location>(){

              public void onSuccess(Location location){
                  if (location!=null){
                      //location success
                      // cordinates
                      txtlocation.setText("latitude"+location.getLatitude()+" \nlongtitude "+location.getLongitude());
                      getAddress(location.getLatitude(),location.getLongitude() );
                  }else{
                      showToast("no location found");
                  }

              }

        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                showToast("something is wrong.Try again later"+e.getMessage());

            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions, @NonNull int[] grantResults) {
         super.onRequestPermissionsResult(requestCode, permissions, grantResults);
         if (requestCode==1111){
             if (grantResults.length>0){
                 if (grantResults[0]==PackageManager.PERMISSION_GRANTED && grantResults[1]==PackageManager.PERMISSION_GRANTED) {
                     // granted permission
                     getMyLocation();
                     showToast("permission granted");
                 }else {
                     showToast("Permission denied.you wont access the location");
                 }
                 }else{
showToast("something went wrong");
                 }
             }
         }

  public void getAddress(double lat, double longt){
      Geocoder geocoder= new Geocoder(this, Locale.ENGLISH);
      try {
          List<Address>addressList= geocoder.getFromLocation(lat,longt,1);
          if (addressList.size()>0){

              //fetch adrresses
              String countryName= addressList.get(0).getCountryName();
              String admin = addressList.get(0).getAdminArea();
              String landmark = addressList.get(0).getFeatureName();
                txtAddresses.setText("countryName: "+countryName+"\ncity"+admin+"\nFeatureName"+landmark);

          }
      } catch (IOException e) {
          e.printStackTrace();
          showToast("something went wrong"+e.getMessage() );
      }


  }

    public void showToast(String msg) {
        Toast.makeText(context,msg, Toast.LENGTH_SHORT);
    }
}