package com.example.HomeDeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.MediaRouteButton;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.HomeDeliveryapp.model.Product;
import com.example.HomeDeliveryapp.shop.Shop;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

public class AddShop extends AppCompatActivity {
    EditText eShoptype, eShopname, eShopnumber, eLocaddress;
    ProgressBar progressBar;
    Button ebutton,ebutton1;
    //FirebaseDatabase database;
    // firebase database reference
    ///DatabaseReference myRef;
    String userID;
    private Task task;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shop);


        eShoptype = findViewById(R.id.shType);
        eShopname = findViewById(R.id.shopName);
        eShopnumber = findViewById(R.id.shopNumber);
        eLocaddress = findViewById(R.id.shoplocation);
        ebutton = findViewById(R.id.btnEnter);
        ebutton1=findViewById(R.id.btnproduct);
        progressBar = findViewById(R.id.crtshop);

        //database = FirebaseDatabase.getInstance();
        // myRef = database.getReference();

        //saveDataToFirebase(new Shop("Test","My Shop","453235","897-YHU"));


        // myRef = database.getReference().child("AddShop");
        //myRef.setValue("");
        ebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String shoptype = eShoptype.getText().toString();
                String shopname = eShopname.getText().toString();
                String shopnumber = eShopnumber.getText().toString().trim();
                String location = eLocaddress.getText().toString().trim();

                if (TextUtils.isEmpty(shoptype)) {
                    eShoptype.setError("provide shop type");
                    return;
                }
                if (TextUtils.isEmpty(shopname)) {
                    eShopname.setError("must provide shop name");
                    return;
                }

                if (TextUtils.isEmpty(location)) {
                    eLocaddress.setError("location address cant be empty");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                //register user to firebase
                // myRef.setValue("eShoptype, eShopname, eShopnumber, eLocaddress");
                Shop shop = new Shop(shoptype, shopname, shopnumber, location);
                saveDataToFirebase(shop);
            }
        });

    }

    private void saveDataToFirebase(Shop shop) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        //firebase database reference
        DatabaseReference myRef = database.getReference("shops");
        myRef.push().setValue(shop);
        finish();

        ebutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(AddShop.this,AddProductActivity.class);
                startActivity(intent);

                }


        });
    }
}