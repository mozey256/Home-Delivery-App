package com.example.HomeDeliveryapp.shop;

public class Shop {
    //private String eshoptype;
    private String eShoptype;
        private String eShopname;
        private String eShopnumber;
    private String eLocaddress;

    public String geteShoptype() {
        return eShoptype;
    }

    public void seteShoptype(String eShoptype) {
        this.eShoptype = eShoptype;
    }

    public String geteShopname() {
        return eShopname;
    }

    public void seteShopname(String eShopname) {
        this.eShopname = eShopname;
    }

    public String geteShopnumber() {
        return eShopnumber;
    }

    public void seteShopnumber(String eShopnumber) {
        this.eShopnumber = eShopnumber;
    }

    public String geteLocaddress() {
        return eLocaddress;
    }

    public void seteLocaddress(String eLocaddress) {
        this.eLocaddress = eLocaddress;
    }

    public Shop( String eShoptype, String eShopname, String eShopnumber, String eLocaddress) {
        this.eShoptype = eShoptype;
        this.eShopname = eShopname;
        this.eShopnumber = eShopnumber;
        this.eLocaddress = eLocaddress;
    }

    public Shop() {
    }
}
