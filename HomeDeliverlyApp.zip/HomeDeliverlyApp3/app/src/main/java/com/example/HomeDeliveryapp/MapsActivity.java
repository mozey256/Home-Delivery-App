package com.example.HomeDeliveryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MapsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps2);
        this.setTitle("Maps Activity");
    }
}