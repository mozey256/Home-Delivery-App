package com.example.HomeDeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login_Activity extends AppCompatActivity {
      EditText mEmail,mPassword;
      Button mLoginBtn;
      FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);


          mEmail = findViewById(R.id.Email);
          mPassword = findViewById(R.id.editTextTextPassword);
          mLoginBtn = findViewById(R.id.btnLogin);
          fAuth = FirebaseAuth.getInstance();
        Button accountbtn=findViewById(R.id.createAcc);

        mLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = mEmail.getText().toString();
                String Password = mPassword.getText().toString().trim();
                if (TextUtils.isEmpty(Password)) {
                    mPassword.setError("provide the password");
                    return;
                }
                if (Password.length() < 6) {
                    mPassword.setError("must be greater than 6 digits");
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("user name is required");
                    return;
                }
                //authenticate the user
                fAuth.signInWithEmailAndPassword(email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(login_Activity.this, "logged in successfully", Toast.LENGTH_SHORT);
                            startActivity(new Intent(getApplicationContext(), Account_Type.class));

                        }else {
                            Toast.makeText(login_Activity.this, "password or email is incorrect !" + task.getException().getMessage(), Toast.LENGTH_SHORT);
                        }
                    }
                });
            }
        });

        accountbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(login_Activity.this,UserInfo .class);
                startActivity(intent);
                Toast.makeText(login_Activity.this,"choose type",Toast.LENGTH_SHORT).show();
            }
        });


    }
}