package com.example.HomeDeliveryapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.example.HomeDeliveryapp.model.Product;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.rpc.context.AttributeContext;

import org.w3c.dom.Document;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class UserInfo extends AppCompatActivity {
    EditText editNames, mEmail, mPassword, editPhone, editadress;
     Button btnSave;
    ProgressBar progressBar;
    FirebaseFirestore fstore;
    FirebaseAuth fAuth;
    String userID;
    private Object Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_info);
        //set button
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        mEmail = findViewById(R.id.edEmail);
        editNames = findViewById(R.id.editNames);
        mPassword = findViewById(R.id.editpass1);
        editPhone = findViewById(R.id.editPhone);
        editadress = findViewById(R.id.editadress);
        btnSave = findViewById(R.id.btnSave);
        fstore = FirebaseFirestore.getInstance();
        fAuth = FirebaseAuth.getInstance();
        progressBar = findViewById(R.id.createText);

        final Button btnSave = findViewById(R.id.btnSave);

          //if the user has account,go directly to main activity
        if (fAuth.getCurrentUser() !=null){
          /*  startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();*/
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = mEmail.getText().toString();
                String fullNames = editNames.getText().toString();
                String Password = mPassword.getText().toString().trim();
                String phoneNumber = editPhone.getText().toString().trim();
                String address = editadress.getText().toString();

                if (TextUtils.isEmpty(Password)) {
                    mPassword.setError("provide the password");
                    return;
                }
                if (Password.length() < 6) {
                    mPassword.setError("must be greater than 6 digits");
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("user name is required");
                    return;
                }
                if (TextUtils.isEmpty(fullNames)) {
                    editNames.setError("your names are required");
                    return;
                }
                if (TextUtils.isEmpty(address)) {
                    editadress.setError("Enter your address please");
                    return;
                }
                if (TextUtils.isEmpty(phoneNumber)) {
                    editPhone.setError("you must enter phone number");
                    return;
                }
                if (phoneNumber.length() < 10) {
                    editPhone.setError("missing numbers");
                    return;
                }
                progressBar .setVisibility(View.VISIBLE);
                //register user to firebase
                fAuth.createUserWithEmailAndPassword(email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(UserInfo.this, "user created successfully", Toast.LENGTH_SHORT);
                            startActivity(new Intent(getApplicationContext(), login_Activity.class));
                        }else{
                            Toast.makeText(UserInfo.this, "Error !" + task.getException().getMessage(), Toast.LENGTH_SHORT);

                        }
                }

            });
        }

        });
    }
}